from django.urls import path
from .views import *

urlpatterns = [
    path('products', products_view),
    path('product', create_product),
    path('product/<int:pk>', change_product),

    path('cart', carts_view),
    path('cart/<int:pk>', change_carts),

    path('order', change_order),

    path('login', login),
    path('signup', register_view),
    path('logout', logout),
]
