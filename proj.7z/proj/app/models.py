from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    email = models.EmailField(unique=True)
    fio = models.CharField(max_length=50)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'fio']

    def __str__(self):
        return self.email


class Products(models.Model):
    name = models.CharField(max_length=10)
    description = models.CharField(max_length=10)
    price = models.IntegerField()

    def __str__(self):
        return self.name


class Carts(models.Model):
    product = models.ForeignKey('Products', on_delete=models.CASCADE)
    user = models.ForeignKey('User', on_delete=models.CASCADE)

    def __str__(self):
        return self.user.email


class Orders(models.Model):
    products = models.ManyToManyField('Products')
    user = models.ForeignKey('User', on_delete=models.CASCADE)
    order_price = models.IntegerField()

    def __str__(self):
        return self.user.email
