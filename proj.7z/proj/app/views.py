from django.shortcuts import render
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from rest_framework.response import Response
from .models import *
from .serializers import *
from .permissions import IsClient


@api_view(['get'])
def products_view(request):
    products = Products.objects.all()
    prod_ser = ProductsSer(products, many=True)
    return Response({'data': prod_ser.data})


@api_view(['POST'])
@permission_classes([IsAdminUser])
def create_product(request):
    prod_ser = ProductsSer(data=request.data)
    if prod_ser.is_valid():
        prod_ser.save()
        return Response(
            {'data': {'id': prod_ser.data['id'], 'message': 'Product added'}})
    return Response({'error': {'code': 422, 'message': 'Validation error',
                               'errors': prod_ser.errors}}, status=422)


@api_view(['DELETE', 'PATCH'])
@permission_classes([IsAdminUser])
def change_product(request, pk):
    try:
        product = Products.objects.get(pk=pk)
    except:
        return Response({'error': {'code': 403, 'message': 'Not Found'}})
    if request.method == 'DELETE':
        product.delete()
        return Response({'data': {'message': 'Product removed'}})
    elif request.method == 'PATCH':
        prod_ser = ProductsSer(data=request.data, instance=product,
                               partial=True)
        if prod_ser.is_valid():
            prod_ser.save()
            return Response({'data': prod_ser.data})
        return Response({'error': {'code': 422, 'message': 'Validation error',
                                   'errors': prod_ser.errors}}, status=422)


@api_view(['GET'])
@permission_classes([IsClient])
def carts_view(request):
    carts = Carts.objects.filter(user=request.user)
    cart_ser = CartsSer(carts, many=True)
    return Response({'data': cart_ser.data})


@api_view(['DELETE', 'POST'])
@permission_classes([IsClient])
def change_carts(request, pk):
    if request.method == 'DELETE':
        try:
            cart = Carts.objects.get(pk=pk)
        except:
            return Response({'error': {'code': 403, 'message': 'Not Found'}})
        cart.delete()
        return Response({'data': {'message': 'Item removed from cart'}})
    elif request.method == 'POST':
        try:
            product = Products.objects.get(pk=pk)
        except:
            return Response({'error': {'code': 403, 'message': 'Not Found'}})
        Carts.objects.create(user=request.user, product=product)
        return Response({'data': {'message': 'Item add to cart'}})


@api_view(["GET", 'POST'])
@permission_classes([IsClient])
def change_order(request):
    if request.method == 'GET':
        orders = Orders.objects.filter(user=request.user)
        order_ser = OrdersSer(orders, many=True)
        return Response({'data': order_ser.data})
    elif request.method == 'POST':
        try:
            carts = Carts.objects.filter(user=request.user)
        except:
            return Response({'error': {'code': 403, 'message': 'Not Found'}})
        order = Orders.objects.create(user=request.user, order_price=0)
        order_price = 0
        if len(order) == 0:
            return Response(
                {'error': {'code': 403, 'message': 'Cart is empty'}})
        for cart in carts:
            order.products.add(cart.product)
            order_price += cart.product.price
        order.order_price = order_price
        order.save()
        order_ser = OrdersSer(order)
        return Response({
            'data': {'order_id': order_ser.data['id'],
                     'message': 'Order is processed'}
        })


@api_view(['POST'])
def login(request):
    user_ser = LoginSer(data=request.data)
    if user_ser.is_valid():
        try:
            user = User.objects.get(email=user_ser.validated_data['email'])
        except:
            return Response(
                {'error': {'code': 401, 'message': 'Authentication Failed'}})
        token, _ = Token.objects.get_or_create(user=user)
        return Response({'data': {'user_token': token.key}})
    return Response({'error': {
        'code': 422,
        'message': 'Validation error',
        'errors': user_ser.errors
    }}, status=422)


@api_view(['POST'])
def register_view(request):
    user_ser = RegisterSer(data=request.data)
    if user_ser.is_valid():
        user = user_ser.save()
        token = Token.objects.create(user=user)
        return Response({'data': {'user_token': token.key}}, status=200)
    else:
        return Response({'error': {
            'code': 422,
            'message': 'Validation error',
            'errors': user_ser.errors
        }}, status=422)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def logout(request):
    request.user.auth_token.delete()
    return Response({'data': {'message': 'Logout'}})
