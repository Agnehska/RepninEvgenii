import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { BASE_URL } from '../App'

const Register = () => {
  const [errors, setErrors] = useState('')
  const [fio, setFio] = useState('')
  const [password, setPassword] = useState('')
  const [email, setEmail] = useState('')
  const navigate = useNavigate()

  const register = (event) => {
    event.preventDefault()
    fetch(`${BASE_URL}/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, fio })
    })
      .then(data => data.json())
      .then(info => {
        if (info.data) {
          navigate('/login')
        } else {
          setErrors(info.error.message)
        }
      })
  }

  const inputParams = [
    {
      type: 'text',
      placeholder: "ФИО",
      value: fio,
      onChange: (event) => setFio(event.target.value),
      text: 'ФИО'
    },
    {
      type: 'email',
      placeholder: "name@example.com",
      value: email,
      onChange: (event) => setEmail(event.target.value),
      text: 'Email'
    },
    {
      type: 'password',
      placeholder: "Password",
      value: password,
      onChange: (event) => setPassword(event.target.value),
      text: 'Password'
    },
  ]

  const printInputs = inputParams.map(elem => {
    return(
      <div className="form-floating mb-3" key={elem.id}>
      <input type={elem.type}
        className="form-control"
        placeholder={elem.placeholder}
        value={elem.value}
        onChange={elem.onChange}
      />
      <label htmlFor="floatingFio">{elem.text}</label>
    </div>
    )
  }) 
  

  return (
    <div className="row row-cols-1 row-cols-md-3 mb-3 text-center justify-content-center">
      <div className="col">
        <div className="row">
          <p className='error'>{errors}</p>
          <form>
            <h1 className="h3 mb-3 fw-normal">Пожалуйста заполните все поля</h1>

            {printInputs}

            <button 
              className="w-100 btn btn-lg btn-success mb-3" 
              type="submit" onClick={register}>Зарегистрироваться</button>
            <button className="w-100 btn btn-lg btn-outline-secondary" 
            type="submit"
            onClick={() => navigate('/')}>Назад</button>
          </form>
        </div>

      </div>
    </div>
  )
}
export default Register