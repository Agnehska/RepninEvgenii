import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { BASE_URL } from '../App'

const Login = ({ setIsAuth, setToken }) => {
  const [errors, setErrors] = useState('')
  const [password, setPassword] = useState('')
  const [email, setEmail] = useState('')
  const navigate = useNavigate()

  const login = (event) => {
    event.preventDefault()
    fetch(`${BASE_URL}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    })
      .then(data => data.json())
      .then(info => {
        if (info.data) {
          setToken(info.data.user_token)
          setIsAuth(true)
          navigate('/')
        } else {
          setErrors(info.errors.message)
        }
      })
  }
  const inputParams = [
    {
      type: 'email',
      placeholder: "name@example.com",
      value: email,
      onChange: (event) => setEmail(event.target.value),
      text: 'Email',
    },
    {
      type: 'password',
      placeholder: "Password",
      value: password,
      onChange: (event) => setPassword(event.target.value),
      text: 'Password'
    },
  ]

  const printInputs = inputParams.map(elem => {
    return(
      <div className="form-floating mb-3" key={elem.id}>
      <input type={elem.type}
        className="form-control"
        placeholder={elem.placeholder}
        value={elem.value}
        onChange={elem.onChange}
      />
      <label htmlFor="floatingFio">{elem.text}</label>
    </div>
    )
  }) 

  return (
    <div className="row row-cols-1 row-cols-md-3 mb-3 text-center justify-content-center">
      <div className="col">
        <div className="row">
          <p className='error'>{errors}</p>
          <form>
            {printInputs}
            <button className="w-100 btn btn-lg btn-success mb-3" type="submit" 
            onClick={login}>Войти</button>
            <button className="w-100 btn btn-lg btn-outline-secondary" 
            type="submit"
            onClick={() => navigate('/')}>Назад</button>
          </form>
        </div>
      </div>
    </div>
  )
}

export default Login
