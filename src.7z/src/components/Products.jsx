import { useEffect, useState } from 'react'
import { BASE_URL } from '../App'

const Products = ({ token, isAuth }) => {
  const [products, setProducts] = useState([])

  useEffect(() => {
    fetch(`${BASE_URL}/products`)
      .then(data => data.json())
      .then(info => setProducts(info.data))
  }, [])

  const addToCart = (id) => {
    fetch(`${BASE_URL}/cart/${id}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    })
  }

  const printProducts = products.map(prod => {
    return (
      <div className="col" key={prod.id}>
        <div className="card mb-4 rounded-3 shadow-sm">
          <div className="card-header py-3">
            <h4 className="my-0 fw-normal">{prod.name}</h4>
          </div>
          <div className="card-body">
            <h1 className="card-title pricing-card-title">{prod.price}р.</h1>
            <p>{prod.description}</p>
            {
              isAuth && <button type="button" onClick={() => addToCart(prod.id)} className="w-100 btn btn-lg btn-outline-success">Добавить в корзину</button>
            }
          </div>
        </div>
      </div>
    )
  })

  return (
    <div className="row row-cols-1 row-cols-md-3 mb-3 text-center">
      {printProducts}
    </div>
  )
}


export default Products