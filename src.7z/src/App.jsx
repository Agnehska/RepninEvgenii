import { useState } from 'react';
import { Route, Routes } from 'react-router-dom'
import Header from './components/Header'
import Products from './components/Products'
import Login from './components/Login'
import Register from './components/Register'
import Cart from './components/Cart'
import Order from './components/Order'

import './App.css';
import './css/bootstrap.min.css'

export const BASE_URL = 'https://api-shop.edu.alabuga.space/api-shop'

function App() {
  const [isAuth, setIsAuth] = useState(false)
  const [token, setToken] = useState('')
  return (
    <div className="App">
      <Header isAuth={isAuth} setIsAuth={setIsAuth} token={token} setToken={setToken} />
      <Routes>
        <Route path='/' element={<Products isAuth={isAuth} token={token} />} />
        <Route path='/login' element={<Login setIsAuth={setIsAuth} setToken={setToken} />} />
        <Route path='/reg' element={<Register />} />
        <Route path='/cart' element={<Cart token={token} />} />
        <Route path='/order' element={<Order token={token} />} />
      </Routes>
    </div>
  );
}

export default App;
